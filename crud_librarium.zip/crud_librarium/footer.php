   <!-- Footer -->
        <div class="footer">
                <div class="container text-center text-white">
                    Copyright &copy; 2025 PPLG Workshop. All rights reserved.
                </div>
            </div>
         <script src="js/bootstrap.bundle.min.js"></script>
    </body>
</html>